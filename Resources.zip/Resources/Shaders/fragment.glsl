#version 330 core

in vec3 vNormal;
in vec2 vTexCoord;

out vec4 fragColor;

uniform vec3 uColor;
uniform vec3 uLightPos = vec3(5.0, 5.0, 5.0);
uniform sampler2D uTexture;
uniform int uUseTexture;

void main()
{
    vec3 normal = normalize(vNormal);
    vec3 lightDir = normalize(uLightPos);
    float diff = max(dot(normal, lightDir), 0.0);
    
    float ambient = 0.3;
    float brightness = ambient + diff * 0.7;
    
    vec3 finalColor;
    if (uUseTexture == 1)
    {
        vec4 texColor = texture(uTexture, vTexCoord);
        finalColor = texColor.rgb * brightness;
    }
    else
    {
        finalColor = uColor * brightness;
    }
    
    fragColor = vec4(finalColor, 1.0);
}